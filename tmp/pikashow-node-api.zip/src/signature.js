import crypto from "crypto";

export function getPikashowHeaders() {
  const apiKey = process.env.PIKASHOW_API_KEY;
  const secret = process.env.PIKASHOW_HMAC_SECRET;

  const timestamp = Math.floor(Date.now() / 1000).toString();
  const message = `${apiKey}:${timestamp}`;

  const signature = crypto
    .createHmac("sha256", secret)
    .update(message)
    .digest("hex");

  return {
    "X-API-Key": apiKey,
    "X-Timestamp": timestamp,
    "X-Signature": signature,
    "User-Agent": "Pikashow/2509030 (Android 13; Pixel 5; Channel/pikashow)",
    "Host": "manoda.co"
  };
}
