import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { listContent, getStream } from "./pikashow.js";

dotenv.config();
const app = express();

app.use(cors());
app.use(express.json());

app.get("/api/list", async (req, res) => {
  try {
    const type = req.query.type || "hollywood";
    const data = await listContent(type);
    res.json(data);
  } catch (e) {
    res.status(500).json({ error: "Failed to load list" });
  }
});

app.get("/api/stream", async (req, res) => {
  try {
    const data = await getStream(req.query);
    res.json(data);
  } catch (e) {
    res.status(500).json({ error: "Failed to load stream" });
  }
});

app.listen(process.env.PORT || 3000, () =>
  console.log("🔥 Pikashow Node API running")
);
