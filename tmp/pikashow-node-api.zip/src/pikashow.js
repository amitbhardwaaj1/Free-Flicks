import axios from "axios";
import { getPikashowHeaders } from "./signature.js";

const BASE = "https://manoda.co/v1/api";

export async function listContent(type) {
  const res = await axios.get(`${BASE}/videos`, {
    params: { type, channel: "pikashow" },
    headers: getPikashowHeaders()
  });
  return res.data;
}

export async function getStream({ type, title, videoId }) {
  const res = await axios.get(`${BASE}/video`, {
    params: {
      type,
      title,
      videoId,
      noseasons: 1,
      noepisodes: 0
    },
    headers: getPikashowHeaders()
  });
  return res.data;
}
